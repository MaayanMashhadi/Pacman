This project is a Pacman game, which was written in C++ language.
On this game the user can choose which board to load (board file), or
to load all the file together, to play with color or defult color (white), and the difficulty level.
I used the fundamentals of oop, design patterns, loaded files, and efficiency algorithm.
